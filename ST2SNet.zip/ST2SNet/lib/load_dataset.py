import os

import numpy as np
import pandas as pd


def load_st_dataset(dataset):
    #output B, N, D
    if dataset == 'PEMSD4':
        data_path = os.path.join('data/PEMSD4/PEMS04.npz')
        data = np.load(data_path)['data'][:, :, 0]  #onley the first dimension, traffic flow data
    elif dataset == 'PEMSD8':
        data_path = os.path.join('data/PEMSD8/PEMS08.npz')
        data = np.load(data_path)['data'][:, :, 0]  #onley the first dimension, traffic flow data
    else:
        raise ValueError
    if len(data.shape) == 2:
        data = np.expand_dims(data, axis=-1)
    print('Load %s Dataset shaped: ' % dataset, data.shape, data.max(), data.min(), data.mean(), np.median(data))
    return data


def load_adj_matrix(dataset, num_nodes=307):
    # output B, N, D
    if dataset == "PEMSD4":
        data_path = os.path.join("./data/PeMSD4/PEMS04.csv")
    elif dataset == "PEMSD8":
        data_path = os.path.join("./data/PeMSD8/PEMS08.csv")
    elif dataset == "METR-LA":
        data_path = os.path.join("./data/METR-LA/distance.csv")
    elif dataset == "PEMS-BAY":
        data_path = os.path.join("./data/PEMS-BAY/distance.csv")
    else:
        raise ValueError
    data = pd.read_csv(data_path).values
    adj_matrix = np.zeros((num_nodes, num_nodes))
    distance_matrix = np.zeros((num_nodes, num_nodes))
    for r in range(data.shape[0]):
        i, j, v = data[r]
        i = int(i)
        j = int(j)
        adj_matrix[i][j] = 1
        # adj_matrix[j][i] = 1
        distance_matrix[i][j] = v
        # distance_matrix[j][i] = v
    return adj_matrix.astype(np.float32), distance_matrix.astype(np.float32)
