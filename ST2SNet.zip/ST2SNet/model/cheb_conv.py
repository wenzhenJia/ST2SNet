# -*- coding:utf-8 -*-
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops.einops import rearrange
from scipy.sparse.linalg import eigs


def get_normalized_adj(W, sigma2=0.1, epsilon=0.5, scaling=True):
    """
    Load weight matrix function.
    :param file_path: str, the path of saved weight matrix file.
    :param sigma2: float, scalar of matrix W.
    :param epsilon: float, thresholds to control the sparsity of matrix W.
    :param scaling: bool, whether applies numerical scaling on W.
    :return: np.ndarray, [n_route, n_route].
    """
    # try:
    #     W = pd.read_csv(file_path, header=None).values
    # except FileNotFoundError:
    #     print(f"ERROR: input file was not found in {file_path}.")
    # check whether W is a 0/1 matrix.
    if set(np.unique(W)) == {0, 1}:
        print('The input graph is a 0/1 matrix; set "scaling" to False.')
        scaling = False
    W_copy = W.copy()
    W_copy[W_copy > 0] = 1
    res = W
    if scaling:
        n = W.shape[0]
        W = W / 10000.0
        W2, W_mask = W * W, (np.ones([n, n]) - np.identity(n)) * W_copy
        # refer to Eq.10
        res = np.exp(-W2 / sigma2) * (np.exp(-W2 / sigma2) >= epsilon) * W_mask
    return res.astype(np.float32)


def scaled_Laplacian(W):
    """
    compute \tilde{L}

    Parameters
    ----------
    W: np.ndarray, shape is (N, N), N is the num of vertices

    Returns
    ----------
    scaled_Laplacian: np.ndarray, shape (N, N)

    """

    assert W.shape[0] == W.shape[1]

    D = np.diag(np.sum(W, axis=1))

    L = D - W

    lambda_max = eigs(L, k=1, which="LR")[0].real

    return (2 * L) / lambda_max - np.identity(W.shape[0])


def cheb_polynomial(L_tilde, K):
    """
    compute a list of chebyshev polynomials from T_0 to T_{K-1}

    Parameters
    ----------
    L_tilde: scaled Laplacian, np.ndarray, shape (N, N)

    K: the maximum order of chebyshev polynomials

    Returns
    ----------
    cheb_polynomials: list(np.ndarray), length: K, from T_0 to T_{K-1}

    """

    N = L_tilde.shape[0]

    cheb_polynomials = [np.identity(N), L_tilde.copy()]

    for i in range(2, K):
        cheb_polynomials.append(
            2 * L_tilde * cheb_polynomials[i - 1] - cheb_polynomials[i - 2]
        )

    return cheb_polynomials


class cheb_conv(nn.Module):
    """
    K-order chebyshev graph convolution
    """

    def __init__(self, args):
        """
        :param K: int
        :param in_channles: int, num of channels in the input sequence
        :param out_channels: int, num of channels in the output sequence
        """
        super(cheb_conv, self).__init__()
        self.K = args.Ks
        # adaptive ***
        # self.nodevec1 = nn.Parameter(torch.randn(args.dim, 10), requires_grad=True)
        # self.nodevec2 = nn.Parameter(torch.randn(10, args.dim), requires_grad=True)
        # L_tilde = F.softmax(F.relu(torch.mm(self.nodevec1, self.nodevec2)), dim=1).detach().numpy()
        # ***
        # adj ***
        L_tilde = scaled_Laplacian(args.adj_matrix)
        # ***

        cheb_polynomials = [
            torch.from_numpy(i).type(torch.FloatTensor).cuda()
            for i in cheb_polynomial(L_tilde, self.K)
        ]
        self.in_channels = args.input_dim
        self.out_channels = 1
        self.cheb_polynomials = cheb_polynomials

        self.Theta = nn.ParameterList(
            [
                nn.Parameter(
                    torch.FloatTensor(self.in_channels, self.out_channels).cuda()
                )
                for _ in range(self.K)
            ]
        )

    def forward(self, x):
        """
        Chebyshev graph convolution operation
        :param x: (batch_size, N, F_in, T)
        :return: (batch_size, N, F_out, T)
        """
        x = torch.unsqueeze(x, dim=-1)
        x = rearrange(x, 'b t n f -> b n f t')
        batch_size, num_of_vertices, in_channels, num_of_timesteps = x.shape

        outputs = []

        for time_step in range(num_of_timesteps):

            graph_signal = x[:, :, :, time_step]  # (b, N, F_in)

            output = torch.zeros(
                batch_size, num_of_vertices, self.out_channels
            ).cuda()  # (b, N, F_out)

            for k in range(self.K):

                T_k = self.cheb_polynomials[k]  # (N,N)

                theta_k = self.Theta[k]  # (in_channel, out_channel)

                rhs = graph_signal.permute(0, 2, 1).matmul(T_k).permute(0, 2, 1)

                output = output + rhs.matmul(theta_k)

            outputs.append(output.unsqueeze(-1))

        x = torch.cat(outputs, dim=-1)
        x = F.relu(x) * x
        x = rearrange(x, 'b n f t -> b t n f')
        return torch.squeeze(x)
